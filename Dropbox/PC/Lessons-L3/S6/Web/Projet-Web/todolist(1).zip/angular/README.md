
## Start

```bash
# Install dependencies
npm install

# Serve on localhost:4200
ng serve

```
